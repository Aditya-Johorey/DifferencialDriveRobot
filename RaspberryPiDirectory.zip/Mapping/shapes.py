import cv2

def circle():
    params = cv2.SimpleBlobDetector_Params()
    params.filterByArea = True
    params.minArea = 1500
    params.maxArea = 10000
    params.filterByCircularity = True
    params.minCircularity = 0.5
    params.filterByConvexity = True
    params.filterByInertia = True
    params.minInertiaRatio = 0.7
    params.filterByColor = False

    return [params, 0]

def rectangle():
    params = cv2.SimpleBlobDetector_Params()
    params.thresholdStep = 255
    params.minRepeatability = 1
    params.filterByColor = True
    params.blobColor = 255
    params.filterByCircularity = False
    params.filterByArea = False
    params.filterByInertia = True
    params.minInertiaRatio = 0.4
    params.maxInertiaRatio = 0.6
    params.filterByConvexity = True
    params.minConvexity = 0.85

    return [params, 1]

def triangle():
    params = cv2.SimpleBlobDetector_Params()
    params.thresholdStep = 255
    params.minRepeatability = 1

    params.blobColor = 255

    params.filterByColor = False
    params.filterByArea = True
    params.filterByCircularity = True
    params.filterByInertia = True
    params.minInertiaRatio = 0.7
    params.filterByConvexity = True
    params.minConvexity = 0.9
    params.minArea = 1500
    params.maxArea = 10000
    params.minCircularity = 0.5  
    params.maxCircularity = 1.0

    
    return [params, 2]

def star():
    # mask = masked_image
    params = cv2.SimpleBlobDetector_Params()
    params.thresholdStep = 255
    params.minRepeatability = 1

    params.blobColor = 255

    params.filterByColor = True
    params.filterByArea = True
    params.filterByCircularity = True
    params.filterByInertia = False
    params.filterByConvexity = False
    params.minArea = 100
    params.maxArea = 20000
    params.minCircularity = 0.0  # Only detect blobs that are somewhat circular
    params.maxCircularity = 0.5

    return [params, 3]