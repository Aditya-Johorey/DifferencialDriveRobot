import shapes
import cv2

def red(hsv):
    redMin = (0, 150, 50)  # Lower bound for red (lower hue value)
    redMax = (10, 255, 255)  # Upper bound for red (higher hue value)
    #Upper range
    redMin1 = (175, 50, 20)
    redMax1 = (180, 255,255)

    mask1 = cv2.inRange(hsv, redMin, redMax)
    mask2 = cv2.inRange(hsv, redMin1, redMax1)
    mask = cv2.bitwise_or(mask1, mask2)
    return [mask, 0]

def blue(hsv):
    # Lower range
    blueMin = (100, 150, 50)  # Minimum hue, saturation, value for "blue"
    blueMax = (130, 255, 255)  # Maximum hue, saturation, value for "blue"

    # Mask for dark blue
    mask = cv2.inRange(hsv, blueMin, blueMax)

    return [mask, 1]

def green(hsv):
    # Lower range
    greenMin = (35, 100, 40)  # Lower bound for green
    greenMax = (85, 255, 255)  # Upper bound for green

    # Mask for dark green
    mask = cv2.inRange(hsv, greenMin, greenMax)

    return [mask, 2]

def purple(hsv):
    # Lower range
    purpleMin = (130, 50, 50)  # Lower bound for purple
    purpleMax = (160, 255, 255)  # Upper bound for purple

    # Mask for purple
    mask = cv2.inRange(hsv, purpleMin, purpleMax)

    return [mask, 3]