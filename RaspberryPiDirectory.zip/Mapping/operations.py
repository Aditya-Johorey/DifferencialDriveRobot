from SerialCom import *
from functions import reading, pause
import time
import datetime
import blob
import aruco_test
arduino = SerialCommunication()
op = Operations(arduino)
map = [0,0,0,0,0]
margin = 10
pastFour = []
def check(currReading):
    match = True
    for i in pastFour:
        if i[0] != currReading[0]: 
            match = False
            break
    if match: op.startCar()
    pastFour.insert(0, currReading)
    if(len(pastFour) > 4 ):
        pastFour.pop(len(pastFour) - 1)

def waitResponse():
    x = time.time()
    while True:
        y = time.time()
        try:
            if int(arduino.read()) != 10:
                arduino.arduino.flushInput()
                print("Turning")
            elif (y - x) >= 20 : op.startCar()
            else: break
        except ValueError:
            continue

if bool(int(input("Enter 1 or 0: "))):
    op.startCar()
    while True:
        try: 
            distances = arduino.readDistances()
            detectBlob = blob.checkForBlob()
            if(distances):
                print(distances)
                if distances[0] < 25 or (distances[3] <= 25 and distances[4] <= 25):
                    # distance 0 = Infrared distance
                    # distance 1 = Right usonic distance
                    # distance 2 = Left usonic distance
                    # distance 3 = Left front usonic distance
                    # distance 5 = Right front usonic distance
                    if(distances[1] > distances[2]): op.rightTurn()
                    else: op.leftTurn()
                    
                # elif distances[4] < 10: 
                #     op.leftTurn30()
                # elif distances[3] < 10:
                #     op.rightTurn30()
                elif distances[0] > 50:
                    op.startCar()
                    continue
                time.sleep(0.1)
                waitResponse()
        except UnboundLocalError:
            print("Can't Read input")
        except TypeError:
            print("Wrong input type. Probably None.")
            op.startCar()
        except KeyboardInterrupt:
            op.stopCar()
            print("Exiting...")
            break
        
        color = detectBlob[0]
        shape = detectBlob[1]
        if color == 0 or color == 2 : 
            op.stopCar()
        if shape == 0 or shape == 1:
            op.startCar()
        elif shape == 2:
            op.rightTurn()
        elif shape == 3:
            op.leftTurn()
        if aruco_test.checkAruco(): op.stopCar()

# while True:

#     try:
#         distance = int(arduino.read())
#     except ValueError:
#         continue
#     print(f'Distance: {distance}')
#     if distance: 
#         if(len(map)>= distance // 5): map[distance // 5] = 1
#         print(map)
#     time.sleep(2)

# op.startCar()
# time.sleep(5)
# op.stopCar()
# reading(arduino)


# arduino.write(1)
# # while True: 
# #     if not arduino.read():
# #         break
# #     print("No input")
# arduino.read()
# arduino.close()
