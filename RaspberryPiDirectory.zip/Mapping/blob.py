
# Machine vision lab - Practical Robotics
# test_camera.py: Grab the camera framebuffer in OpenCV and display using cv2.imshow


# Import the necessary packages
import picamera2
import time
import cv2
import colors
import shapes

masks = [colors.red, colors.green, colors.blue, colors.blue]
polygons = [shapes.circle, shapes.rectangle, shapes.star, shapes.triangle]

def detect(mask, params):
	detector = cv2.SimpleBlobDetector_create(params[0])
	keypoints = detector.detect(mask[0])
	if(keypoints): 
		# for keypoint in keypoints:
		# 	print(f"Blob: x = {keypoint.pt[0]}, y = {keypoint.pt[1]}, size = {keypoint.size}")
		return [mask[1], params[1]]
	kp_image = cv2.drawKeypoints(mask[0],keypoints,None, color=(0,0,255), flags= cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS )

	cv2.imshow("Frame", kp_image)

def checkForBlob():
	# Initialise the camera and create a reference to it
	camera = picamera2.Picamera2()
	config = camera.create_preview_configuration(main={'format': 'RGB888', 'size' : (640,480)})
	camera.configure(config)
	camera.start()

	# Allow the camera time to warm up
	time.sleep(0.1)

	while True:
		image = camera.capture_array("main")
		image = cv2.rotate(image, cv2.ROTATE_180)
		hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
		
		for func in masks:
			mask = func(hsv)
			for shape in polygons:
				params = shape()

				return detect(mask, params)

		

		# if the `q` key was pressed, break from the loop
		if cv2.waitKey(1) & 0xFF == ord("q"):
			break
