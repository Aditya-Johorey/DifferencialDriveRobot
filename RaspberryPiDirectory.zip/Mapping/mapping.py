import numpy as np
from functions import *


map = np.zeros((32, 42))
map = generateMap(map)


print(map)

