import serial
import constants

#Creating a class for serial communications between RaspberryPi and ARB board
class SerialCommunication:
    def __init__(self, port = "/dev/ttyUSB0", baud = 115200, timeout = 1):
       self.port = port
       self.baud = baud
       try: 
           self.arduino = serial.Serial(self.port, self.baud, timeout= timeout)
           print(f"Connected to Arduino on {self.port}")
       except serial.SerialException as e:
           print(f"Error: {e}")
           exit()
           
    def write(self, message):
        self.arduino.write(f'{message}'.encode('utf-8'))
    
    def read(self):
        response = self.arduino.read_until().decode('utf-8').strip()
        if(response): 
            print(f"ARDUINO: {response}")
        return response

    def readDistances(self):
        response = self.arduino.readline().decode('utf-8').strip()
        if(response):
            print(response)
            try:
                response = response.split(",")
                # print(response[:5])
                if response[-1] == "#":
                    self.arduino.flush
                response = [int(i) for i in response[:5]]
                return response
            except ValueError:
                return None

    def close(self):
        self.arduino.close()

class Operations:
    def __init__(self, arduino):
        self.arduino = arduino

    def startCar(self):
        self.arduino.write(constants.START)

    def stopCar(self):
        self.arduino.write(constants.STOP)

    def leftTurn(self):
        self.arduino.write(constants.LEFT)
        print("Left Turn")
        self.arduino.arduino.close()
        self.arduino.arduino.open()

    def rightTurn(self):
        self.arduino.write(constants.RIGHT)
        print("Right Turn")
        self.arduino.arduino.close()
        self.arduino.arduino.open()

    def leftTurn30(self):
        self.arduino.write(constants.LEFT30)
        print("Left Turn")
        self.arduino.arduino.close()
        self.arduino.arduino.open()

    def rightTurn30(self):
        self.arduino.write(constants.RIGHT30)
        print("Right Turn")
        self.arduino.arduino.close()
        self.arduino.arduino.open()

    def enableInput(self):
        self.arduino.write(constants.ENABLE)
        print("Input Enabled")
        self.arduino.arduino.close()
        self.arduino.arduino.open()