import numpy as np
# from ARBPi import *
import time
# Setup the ARB functions
# ARBPiSetup("/dev/ttyUSB0")
#Populating Occupancy Grids with Sensor Data
def polarToCartesian(distance, theta, x, y):
    x = int(distance * np.cos((distance/180) * 3.14))
    y = int(distance * np.sin((theta/180) * 3.14))
 
def generateMap(map):
    map[0] = np.ones((1, 42))
    map[31] = np.ones((1, 42))
    for i in range(30):
        map[i + 1][0] = 1.0
        map[i + 1][41] = 1.0
    return map

def reading(arduino):
    try: 
        while True: 
            if arduino.arduino.in_waiting > 0:
                value = arduino.read()
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("Exiting...")
        arduino.close()

def pause(arduino):
    while True:
        # c = continue
        value = reading(arduino)
        if value[1] == 'c': break
        time.sleep(0.5)
    return False