import time
import pigpio

LED = 5
pi = pigpio.pi()
pi.set_mode(LED, pigpio.OUTPUT)

for i in range(0, 10):
    pi.write(LED, 1)
    time.sleep(1)
    print("On")
    pi.write(LED, 0)
    time.sleep(1)
    print("Off")
